
Perfect! I'll add a surveillance/on-duty widget that fits naturally into the design. Here's the updated version:

## Updated Dashboard with Surveillance Widget

```jsx
// Dashboard.jsx
import React from 'react';
import './Dashboard.css';

const Dashboard = () => {
  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>Dashboard</h1>
        <div className="header-actions">
          <time>{new Date().toLocaleDateString('nb-NO')}</time>
        </div>
      </header>

      <div className="dashboard-grid">
        {/* NEW: Surveillance/On-Duty Widget */}
        <div className="widget widget-surveillance">
          <div className="widget-header">
            <h2>📋 Overvågning Uge 41</h2>
            <span className="status-badge status-active">Aktiv</span>
          </div>
          <div className="widget-content">
            <SurveillanceTeam />
          </div>
        </div>

        {/* Recipe List Widget */}
        <div className="widget widget-recipes">
          <div className="widget-header">
            <h2>Matlån</h2>
            <button className="widget-action">⋯</button>
          </div>
          <div className="widget-content">
            <RecipeList />
          </div>
        </div>

        {/* Featured Image Widget */}
        <div className="widget widget-featured">
          <div className="widget-header">
            <h2>Matbildet (Outer Space)</h2>
          </div>
          <div className="widget-content widget-image">
            <img src="featured-image.jpg" alt="Featured dish" />
          </div>
        </div>

        {/* Rest of your widgets... */}
        <div className="widget widget-weather">
          <div className="widget-header">
            <h2>Været - Odense</h2>
          </div>
          <div className="widget-content">
            <WeatherChart />
          </div>
        </div>

        <div className="widget widget-clock">
          <Clock />
          <div className="widget-subtitle">Uge nummer: 41</div>
        </div>

        <div className="widget widget-stats">
          <div className="widget-header">
            <h2>Rapporterte sikkerhet til Githika</h2>
          </div>
          <div className="widget-content">
            <StatsDisplay />
          </div>
        </div>

        <div className="widget widget-gallery">
          <div className="widget-header">
            <h2>Nyt Domicil</h2>
          </div>
          <div className="widget-content">
            <PhotoGallery />
          </div>
        </div>

        <div className="widget widget-grid-images">
          <div className="widget-content">
            <ImageGrid />
          </div>
        </div>
      </div>
    </div>
  );
};

// NEW: Surveillance Team Component
const SurveillanceTeam = () => {
  const onDutyPersons = [
    {
      id: 1,
      name: "Lars",
      role: "MDM",
      status: "available",
      avatar: "L",
      color: "#3b82f6" // blue
    },
    {
      id: 2,
      name: "Bjarke",
      role: "Batch/EDI",
      status: "available",
      avatar: "B",
      color: "#8b5cf6" // purple
    }
  ];

  return (
    <div className="surveillance-team">
      {onDutyPersons.map(person => (
        <div key={person.id} className="team-member">
          <div 
            className="member-avatar" 
            style={{ backgroundColor: person.color }}
          >
            {person.avatar}
          </div>
          <div className="member-info">
            <h3>{person.name}</h3>
            <p className="member-role">{person.role}</p>
          </div>
          <div className={`member-status status-${person.status}`}>
            <span className="status-indicator"></span>
            Tilgjengelig
          </div>
        </div>
      ))}
    </div>
  );
};

// RecipeList Component
const RecipeList = () => {
  const recipes = [
    {
      id: 1,
      title: "Kartoffel-porresuppe - Cremet kartoffelsuppe med ristede kartoffeltern...",
      day: "Tirsdag",
      date: "7/10",
      icon: "🥔"
    },
    {
      id: 2,
      title: "Økonomiyaki - Sprød kålpandekage toppet med teriyakiraineret...",
      day: "Onsdag",
      date: "8/10",
      icon: "🥘"
    },
    {
      id: 3,
      title: "Brændt blomkål på lun jordskokkepuré, toppet med rejer...",
      day: "Torsdag",
      date: "9/10",
      icon: "🥦"
    },
    {
      id: 4,
      title: "Boller i karry - klassiske boller i karry med ris...",
      day: "Fredag",
      date: "10/10",
      icon: "🍛"
    },
    {
      id: 5,
      title: "Frikadeller med stuvet hvidkål",
      day: "Mandag",
      date: "13/10",
      icon: "🍖"
    }
  ];

  return (
    <ul className="recipe-list">
      {recipes.map(recipe => (
        <li key={recipe.id} className="recipe-item">
          <span className="recipe-icon">{recipe.icon}</span>
          <div className="recipe-details">
            <h3>{recipe.title}</h3>
            <time>{recipe.day} - {recipe.date}</time>
          </div>
        </li>
      ))}
    </ul>
  );
};

// Other components...
const WeatherChart = () => <div className="chart-placeholder">Weather Chart</div>;
const Clock = () => <div className="clock-face">🕐</div>;
const StatsDisplay = () => (
  <div className="stats">
    <div className="stat-item">
      <label>Completed Imports:</label>
      <span className="stat-value">64</span>
    </div>
    <div className="progress-bar">
      <div className="progress-fill" style={{width: '89%'}}>89%</div>
    </div>
  </div>
);
const PhotoGallery = () => <div className="photo-grid">Photo Gallery</div>;
const ImageGrid = () => <div className="image-grid">Image Grid</div>;

export default Dashboard;
```

## Updated CSS with Surveillance Styles

```css
:root {
  --primary-color: #2563eb;
  --success-color: #10b981;
  --warning-color: #f59e0b;
  --danger-color: #ef4444;
  --background: #f8fafc;
  --card-background: #ffffff;
  --text-primary: #1e293b;
  --text-secondary: #64748b;
  --border: #e2e8f0;
  --shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.1);
  --radius: 12px;
  --spacing: 1.5rem;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--background);
  color: var(--text-primary);
  line-height: 1.6;
}

.dashboard {
  min-height: 100vh;
  padding: var(--spacing);
}

.dashboard-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  padding: 0 0.5rem;
}

.dashboard-header h1 {
  font-size: 2rem;
  font-weight: 700;
}

.dashboard-header time {
  color: var(--text-secondary);
  font-size: 0.95rem;
}

/* Grid Layout - Responsive & Flexible */
.dashboard-grid {
  display: grid;
  gap: var(--spacing);
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  grid-auto-rows: min-content;
}

/* Widget Base Styles */
.widget {
  background: var(--card-background);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  overflow: hidden;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
}

.widget:hover {
  box-shadow: var(--shadow-lg);
  transform: translateY(-2px);
}

.widget-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.25rem 1.5rem;
  border-bottom: 1px solid var(--border);
}

.widget-header h2 {
  font-size: 1.1rem;
  font-weight: 600;
}

.widget-action {
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  color: var(--text-secondary);
  padding: 0.25rem 0.5rem;
  border-radius: 6px;
  transition: background 0.2s;
}

.widget-action:hover {
  background: var(--border);
}

.widget-content {
  padding: 1.5rem;
  flex: 1;
}

/* Status Badge */
.status-badge {
  padding: 0.35rem 0.85rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.status-active {
  background: #dcfce7;
  color: #166534;
}

/* NEW: Surveillance Widget Styles */
.widget-surveillance {
  grid-column: 1 / -1; /* Full width */
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
}

.widget-surveillance .widget-header {
  border-bottom-color: rgba(255, 255, 255, 0.2);
}

.widget-surveillance .widget-header h2 {
  color: white;
  font-size: 1.2rem;
}

.widget-surveillance .status-badge {
  background: rgba(255, 255, 255, 0.25);
  color: white;
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.surveillance-team {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
}

.team-member {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: rgba(255, 255, 255, 0.15);
  border-radius: 10px;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  transition: all 0.3s ease;
}

.team-member:hover {
  background: rgba(255, 255, 255, 0.25);
  transform: translateY(-2px);
}

.member-avatar {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
  font-weight: 700;
  color: white;
  flex-shrink: 0;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

.member-info {
  flex: 1;
  min-width: 0;
}

.member-info h3 {
  font-size: 1.1rem;
  font-weight: 600;
  color: white;
  margin-bottom: 0.2rem;
}

.member-role {
  font-size: 0.9rem;
  color: rgba(255, 255, 255, 0.85);
  font-weight: 500;
}

.member-status {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.85rem;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.95);
  padding: 0.4rem 0.8rem;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  white-space: nowrap;
}

.status-indicator {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #10b981;
  box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.3);
  animation: pulse 2s ease-in-out infinite;
}

@keyframes pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
}

.status-available .status-indicator {
  background: #10b981;
  box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.3);
}

.status-busy .status-indicator {
  background: #ef4444;
  box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.3);
}

.status-away .status-indicator {
  background: #f59e0b;
  box-shadow: 0 0 0 2px rgba(245, 158, 11, 0.3);
}

/* Specific Widget Sizes */
.widget-recipes {
  grid-column: span 1;
  grid-row: span 2;
}

.widget-featured {
  grid-column: span 2;
  grid-row: span 2;
}

.widget-weather {
  grid-column: span 2;
}

.widget-clock {
  grid-column: span 1;
}

.widget-gallery {
  grid-column: span 2;
}

/* Recipe List Styles */
.recipe-list {
  list-style: none;
}

.recipe-item {
  display: flex;
  gap: 1rem;
  padding: 1rem;
  border-bottom: 1px solid var(--border);
  transition: background 0.2s;
  cursor: pointer;
}

.recipe-item:last-child {
  border-bottom: none;
}

.recipe-item:hover {
  background: var(--background);
}

.recipe-icon {
  font-size: 2rem;
  flex-shrink: 0;
}

.recipe-details h3 {
  font-size: 0.95rem;
  font-weight: 500;
  margin-bottom: 0.25rem;
  line-height: 1.4;
}

.recipe-details time {
  font-size: 0.85rem;
  color: var(--text-secondary);
}

/* Image Widget */
.widget-image {
  padding: 0;
}

.widget-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

/* Clock Widget */
.widget-clock {
  text-align: center;
}

.clock-face {
  font-size: 8rem;
  padding: 2rem;
}

.widget-subtitle {
  padding: 0 1.5rem 1.5rem;
  color: var(--text-secondary);
  font-size: 0.9rem;
}

/* Stats Widget */
.stats {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.stat-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.stat-value {
  font-size: 2rem;
  font-weight: 700;
  color: var(--primary-color);
}

.progress-bar {
  background: var(--border);
  border-radius: 100px;
  height: 32px;
  overflow: hidden;
}

.progress-fill {
  background: linear-gradient(90deg, #10b981, #059669);
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding-right: 1rem;
  color: white;
  font-weight: 600;
  font-size: 0.9rem;
  transition: width 0.6s ease;
}

/* Responsive Breakpoints */
@media (max-width: 1400px) {
  .widget-featured {
    grid-column: span 2;
  }
}

@media (max-width: 1024px) {
  .dashboard-grid {
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  }
  
  .widget-recipes,
  .widget-featured,
  .widget-weather,
  .widget-gallery {
    grid-column: span 1;
  }
  
  .surveillance-team {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 768px) {
  .dashboard {
    padding: 1rem;
  }
  
  .dashboard-header h1 {
    font-size: 1.5rem;
  }
  
  .dashboard-grid {
    grid-template-columns: 1fr;
    gap: 1rem;
  }
  
  .widget {
    grid-column: span 1 !important;
  }
  
  .clock-face {
    font-size: 5rem;
    padding: 1rem;
  }
  
  .team-member {
    flex-wrap: wrap;
  }
  
  .member-status {
    width: 100%;
    justify-content: center;
  }
}
```

## Key Features of the Surveillance Widget:

✅ **Full-Width Prominence** - Spans the entire dashboard width at the top  
✅ **Eye-Catching Design** - Gradient background with glassmorphism cards  
✅ **Status Indicators** - Live status with pulsing animation  
✅ **Responsive Grid** - Team members stack nicely on mobile  
✅ **Easy to Extend** - Just add more objects to the `onDutyPersons` array  
✅ **Multiple Status Types** - Available, Busy, Away with different colors  

## Adding More Team Members:

```jsx
const onDutyPersons = [
  {
    id: 1,
    name: "Lars",
    role: "MDM",
    status: "available", // available, busy, away
    avatar: "L",
    color: "#3b82f6"
  },
  {
    id: 2,
    name: "Bjarke",
    role: "Batch/EDI",
    status: "available",
    avatar: "B",
    color: "#8b5cf6"
  },
  {
    id: 3,
    name: "Maria",
    role: "Integration",
    status: "busy",
    avatar: "M",
    color: "#ec4899"
  }
];
```

The surveillance widget now sits prominently at the top and scales beautifully across all screen sizes! 🎯