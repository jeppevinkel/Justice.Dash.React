
Perfect! Let's add a recipe modal that opens when you click on a menu item. Here's the complete implementation:

## Updated Dashboard with Recipe Modal

```jsx
// Dashboard.jsx
import React, { useState } from 'react';
import './Dashboard.css';

const Dashboard = () => {
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>Dashboard</h1>
        <div className="header-actions">
          <time>{new Date().toLocaleDateString('nb-NO')}</time>
        </div>
      </header>

      <div className="dashboard-grid">
        {/* Surveillance Widget */}
        <div className="widget widget-surveillance">
          <div className="widget-header">
            <h2>📋 Overvågning Uge 41</h2>
            <span className="status-badge status-active">Aktiv</span>
          </div>
          <div className="widget-content">
            <SurveillanceTeam />
          </div>
        </div>

        {/* Recipe List Widget with click handler */}
        <div className="widget widget-recipes">
          <div className="widget-header">
            <h2>Matlån</h2>
            <button className="widget-action">⋯</button>
          </div>
          <div className="widget-content">
            <RecipeList onRecipeClick={setSelectedRecipe} />
          </div>
        </div>

        {/* Other widgets... */}
        <div className="widget widget-featured">
          <div className="widget-header">
            <h2>Matbildet (Outer Space)</h2>
          </div>
          <div className="widget-content widget-image">
            <img src="featured-image.jpg" alt="Featured dish" />
          </div>
        </div>

        <div className="widget widget-weather">
          <div className="widget-header">
            <h2>Været - Odense</h2>
          </div>
          <div className="widget-content">
            <WeatherChart />
          </div>
        </div>

        <div className="widget widget-clock">
          <Clock />
          <div className="widget-subtitle">Uge nummer: 41</div>
        </div>

        <div className="widget widget-stats">
          <div className="widget-header">
            <h2>Rapporterte sikkerhet til Githika</h2>
          </div>
          <div className="widget-content">
            <StatsDisplay />
          </div>
        </div>

        <div className="widget widget-gallery">
          <div className="widget-header">
            <h2>Nyt Domicil</h2>
          </div>
          <div className="widget-content">
            <PhotoGallery />
          </div>
        </div>

        <div className="widget widget-grid-images">
          <div className="widget-content">
            <ImageGrid />
          </div>
        </div>
      </div>

      {/* Recipe Modal */}
      {selectedRecipe && (
        <RecipeModal 
          recipe={selectedRecipe} 
          onClose={() => setSelectedRecipe(null)} 
        />
      )}
    </div>
  );
};

// Recipe Modal Component
const RecipeModal = ({ recipe, onClose }) => {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </button>

        <div className="modal-grid">
          {/* Recipe Image */}
          <div className="modal-image-section">
            <img src={recipe.image} alt={recipe.title} />
          </div>

          {/* Recipe Details */}
          <div className="modal-details-section">
            <div className="modal-header-content">
              <span className="recipe-icon-large">{recipe.icon}</span>
              <div>
                <h2>{recipe.title}</h2>
                <p className="recipe-meta">
                  <time>{recipe.day} - {recipe.date}</time>
                </p>
              </div>
            </div>

            <div className="recipe-content">
              {/* Ingredients */}
              <section className="recipe-section">
                <h3>Ingredienser:</h3>
                {recipe.ingredients && recipe.ingredients.map((section, idx) => (
                  <div key={idx} className="ingredient-group">
                    <h4>{section.section}</h4>
                    <ul>
                      {section.items.map((item, i) => (
                        <li key={i}>{item}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </section>

              {/* Instructions */}
              <section className="recipe-section">
                <h3>Instruktioner:</h3>
                <ol className="instructions-list">
                  {recipe.instructions && recipe.instructions.map((step, idx) => (
                    <li key={idx}>
                      <strong>{step.title}</strong>
                      <ul>
                        {step.steps.map((substep, i) => (
                          <li key={i}>{substep}</li>
                        ))}
                      </ul>
                    </li>
                  ))}
                </ol>
              </section>

              {/* Final note */}
              {recipe.finalNote && (
                <div className="recipe-note">
                  <strong>{recipe.finalNote}</strong>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Updated RecipeList Component
const RecipeList = ({ onRecipeClick }) => {
  const recipes = [
    {
      id: 1,
      title: "Kartoffel-porresuppe - Cremet kartoffelsuppe med ristede kartoffeltern, syltede løg og bacon crumble",
      day: "Tirsdag",
      date: "7/10",
      icon: "🥔",
      image: "https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800",
      ingredients: [
        {
          section: "Kartoffel-porresuppe",
          items: [
            "1 kg kartofler, skrællet og skåret i tern",
            "2 porrer, renset og skåret",
            "1 løg, hakket",
            "2 fed hvidløg, presset"
          ]
        },
        {
          section: "Bacon crumble",
          items: [
            "200 g bacon, skåret i små tern",
            "100 g havregryn",
            "50 g smør"
          ]
        }
      ],
      instructions: [
        {
          title: "Forbered suppen",
          steps: [
            "Varm olivenolie i en stor gryde",
            "Svits løg og porre i 5 minutter",
            "Tilsæt kartofler og bouillon"
          ]
        },
        {
          title: "Tilbered bacon crumble",
          steps: [
            "Steg bacon sprødt i en pande",
            "Bland med havregryn og smør",
            "Brun i ovnen ved 180°C i 10 minutter"
          ]
        }
      ],
      finalNote: "God appetit!"
    },
    {
      id: 2,
      title: "Økonomiyaki - Sprød kålpandekage toppet med teriyakiraineret kylling, forårsløg og chilimayo",
      day: "Onsdag",
      date: "8/10",
      icon: "🥘",
      image: "https://images.unsplash.com/photo-1626804475297-41608ea09aeb?w=800",
      ingredients: [
        {
          section: "Pandekage",
          items: [
            "300 g hvidkål, fintskåret",
            "150 g mel",
            "3 æg",
            "200 ml dashi eller bouillon"
          ]
        },
        {
          section: "Topping",
          items: [
            "400 g kyllingebryst",
            "Teriyakisauce",
            "Forårsløg",
            "Chilimayo"
          ]
        }
      ],
      instructions: [
        {
          title: "Lav dej",
          steps: [
            "Bland mel, æg og dashi",
            "Fold kål i dejen",
            "Lad hvile i 15 minutter"
          ]
        },
        {
          title: "Steg pandekagerne",
          steps: [
            "Varm en pande med olie",
            "Hæld dej på panden og form til flade kager",
            "Steg 4-5 minutter på hver side"
          ]
        }
      ],
      finalNote: "Servér med ekstra teriyakisauce!"
    },
    {
      id: 3,
      title: "Brændt blomkål på lun jordskokkepuré, toppet med rejer, kinaradiser, æbler og krydderurter",
      day: "Torsdag",
      date: "9/10",
      icon: "🥦",
      image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800",
      ingredients: [
        {
          section: "Blomkål",
          items: [
            "1 helt blomkålshoved",
            "Olivenolie",
            "Salt og peber"
          ]
        },
        {
          section: "Jordskokkepuré",
          items: [
            "500 g jordskokker",
            "100 ml fløde",
            "50 g smør"
          ]
        }
      ],
      instructions: [
        {
          title: "Rist blomkålen",
          steps: [
            "Pensl blomkål med olie",
            "Rist i ovn ved 200°C i 40 minutter",
            "Vend halvvejs"
          ]
        }
      ],
      finalNote: "En smuk vegetarisk ret!"
    },
    {
      id: 4,
      title: "Boller i karry - klassiske boller i karry med ris, toppet med frisk æblesalat",
      day: "Fredag",
      date: "10/10",
      icon: "🍛",
      image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800",
      ingredients: [
        {
          section: "Kødboller",
          items: [
            "500 g hakket oksekød",
            "1 æg",
            "2 spsk mel",
            "Salt og peber"
          ]
        }
      ],
      instructions: [
        {
          title: "Form bollerne",
          steps: [
            "Bland alle ingredienser",
            "Form til små boller",
            "Steg gyldne i smør"
          ]
        }
      ],
      finalNote: "Klassisk dansk comfort food!"
    },
    {
      id: 5,
      title: "Frikadeller med stuvet hvidkål",
      day: "Mandag",
      date: "13/10",
      icon: "🍖",
      image: "https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=800",
      ingredients: [
        {
          section: "Frikadeller",
          items: [
            "500 g svinekød",
            "1 løg, finthakket",
            "1 æg",
            "Mel og mælk"
          ]
        }
      ],
      instructions: [
        {
          title: "Lav frikadellerne",
          steps: [
            "Bland ingredienser til en fast masse",
            "Form flade kager",
            "Steg på medium varme i 4-5 minutter per side"
          ]
        }
      ],
      finalNote: "Servér med kartofler!"
    }
  ];

  return (
    <ul className="recipe-list">
      {recipes.map(recipe => (
        <li 
          key={recipe.id} 
          className="recipe-item"
          onClick={() => onRecipeClick(recipe)}
        >
          <span className="recipe-icon">{recipe.icon}</span>
          <div className="recipe-details">
            <h3>{recipe.title}</h3>
            <time>{recipe.day} - {recipe.date}</time>
          </div>
          <svg className="recipe-arrow" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
            <path d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"/>
          </svg>
        </li>
      ))}
    </ul>
  );
};

// Other components remain the same...
const SurveillanceTeam = () => {
  const onDutyPersons = [
    {
      id: 1,
      name: "Lars",
      role: "MDM",
      status: "available",
      avatar: "L",
      color: "#3b82f6"
    },
    {
      id: 2,
      name: "Bjarke",
      role: "Batch/EDI",
      status: "available",
      avatar: "B",
      color: "#8b5cf6"
    }
  ];

  return (
    <div className="surveillance-team">
      {onDutyPersons.map(person => (
        <div key={person.id} className="team-member">
          <div className="member-avatar" style={{ backgroundColor: person.color }}>
            {person.avatar}
          </div>
          <div className="member-info">
            <h3>{person.name}</h3>
            <p className="member-role">{person.role}</p>
          </div>
          <div className={`member-status status-${person.status}`}>
            <span className="status-indicator"></span>
            Tilgjengelig
          </div>
        </div>
      ))}
    </div>
  );
};

const WeatherChart = () => <div className="chart-placeholder">Weather Chart</div>;
const Clock = () => <div className="clock-face">🕐</div>;
const StatsDisplay = () => (
  <div className="stats">
    <div className="stat-item">
      <label>Completed Imports:</label>
      <span className="stat-value">64</span>
    </div>
    <div className="progress-bar">
      <div className="progress-fill" style={{width: '89%'}}>89%</div>
    </div>
  </div>
);
const PhotoGallery = () => <div className="photo-grid">Photo Gallery</div>;
const ImageGrid = () => <div className="image-grid">Image Grid</div>;

export default Dashboard;
```

## Updated CSS with Modal Styles

Add this to your `Dashboard.css`:

```css
/* Recipe List - Add clickable styling */
.recipe-item {
  display: flex;
  gap: 1rem;
  align-items: center;
  padding: 1rem;
  border-bottom: 1px solid var(--border);
  transition: all 0.2s;
  cursor: pointer;
  position: relative;
}

.recipe-item:last-child {
  border-bottom: none;
}

.recipe-item:hover {
  background: var(--background);
  padding-left: 1.25rem;
}

.recipe-item:active {
  transform: scale(0.98);
}

.recipe-arrow {
  margin-left: auto;
  color: var(--text-secondary);
  transition: transform 0.2s;
}

.recipe-item:hover .recipe-arrow {
  transform: translateX(4px);
  color: var(--primary-color);
}

/* Modal Styles */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.75);
  backdrop-filter: blur(4px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: 2rem;
  animation: fadeIn 0.2s ease;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

.modal-content {
  background: var(--card-background);
  border-radius: var(--radius);
  max-width: 1200px;
  width: 100%;
  max-height: 90vh;
  overflow: hidden;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
  position: relative;
  animation: slideUp 0.3s ease;
  display: flex;
  flex-direction: column;
}

@keyframes slideUp {
  from {
    transform: translateY(50px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

.modal-close {
  position: absolute;
  top: 1.5rem;
  right: 1.5rem;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.5);
  color: white;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10;
  transition: all 0.2s;
  backdrop-filter: blur(10px);
}

.modal-close:hover {
  background: rgba(0, 0, 0, 0.8);
  transform: rotate(90deg);
}

.modal-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  height: 100%;
  overflow: hidden;
}

.modal-image-section {
  position: relative;
  background: #000;
  overflow: hidden;
}

.modal-image-section img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.modal-details-section {
  display: flex;
  flex-direction: column;
  overflow-y: auto;
  max-height: 90vh;
}

.modal-header-content {
  display: flex;
  gap: 1.5rem;
  align-items: flex-start;
  padding: 2rem;
  border-bottom: 2px solid var(--border);
  background: linear-gradient(to bottom, var(--background), var(--card-background));
  position: sticky;
  top: 0;
  z-index: 5;
}

.recipe-icon-large {
  font-size: 3.5rem;
  line-height: 1;
}

.modal-header-content h2 {
  font-size: 1.5rem;
  margin-bottom: 0.5rem;
  line-height: 1.3;
}

.recipe-meta {
  color: var(--text-secondary);
  font-size: 0.95rem;
}

.recipe-content {
  padding: 2rem;
  flex: 1;
}

.recipe-section {
  margin-bottom: 2.5rem;
}

.recipe-section h3 {
  font-size: 1.3rem;
  margin-bottom: 1rem;
  color: var(--primary-color);
  border-bottom: 2px solid var(--primary-color);
  padding-bottom: 0.5rem;
}

.ingredient-group {
  margin-bottom: 1.5rem;
}

.ingredient-group h4 {
  font-size: 1.1rem;
  margin-bottom: 0.75rem;
  color: var(--text-primary);
  font-weight: 600;
}

.ingredient-group ul {
  list-style: none;
  padding: 0;
}

.ingredient-group ul li {
  padding: 0.5rem 0;
  padding-left: 1.5rem;
  position: relative;
  line-height: 1.6;
}

.ingredient-group ul li::before {
  content: "•";
  position: absolute;
  left: 0;
  color: var(--primary-color);
  font-weight: bold;
  font-size: 1.2rem;
}

.instructions-list {
  counter-reset: step-counter;
  list-style: none;
  padding: 0;
}

.instructions-list > li {
  counter-increment: step-counter;
  margin-bottom: 1.5rem;
  position: relative;
  padding-left: 3rem;
}

.instructions-list > li::before {
  content: counter(step-counter);
  position: absolute;
  left: 0;
  top: 0;
  width: 2rem;
  height: 2rem;
  background: var(--primary-color);
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 0.9rem;
}

.instructions-list > li strong {
  display: block;
  margin-bottom: 0.5rem;
  font-size: 1.05rem;
}

.instructions-list > li ul {
  list-style: none;
  padding: 0;
  margin-top: 0.5rem;
}

.instructions-list > li ul li {
  padding: 0.35rem 0;
  padding-left: 1.5rem;
  position: relative;
  line-height: 1.6;
}

.instructions-list > li ul li::before {
  content: "→";
  position: absolute;
  left: 0;
  color: var(--primary-color);
  font-weight: bold;
}

.recipe-note {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 1.5rem;
  border-radius: 10px;
  text-align: center;
  font-size: 1.1rem;
  margin-top: 2rem;
}

/* Responsive Modal */
@media (max-width: 1024px) {
  .modal-grid {
    grid-template-columns: 1fr;
  }
  
  .modal-image-section {
    max-height: 300px;
  }
}

@media (max-width: 768px) {
  .modal-overlay {
    padding: 0;
  }
  
  .modal-content {
    border-radius: 0;
    max-height: 100vh;
    height: 100vh;
  }
  
  .modal-image-section {
    max-height: 250px;
  }
  
  .modal-header-content {
    flex-direction: column;
    gap: 1rem;
    padding: 1.5rem;
  }
  
  .recipe-icon-large {
    font-size: 2.5rem;
  }
  
  .modal-header-content h2 {
    font-size: 1.2rem;
  }
  
  .recipe-content {
    padding: 1.5rem;
  }
  
  .instructions-list > li {
    padding-left: 2.5rem;
  }
}

/* Smooth scroll for modal content */
.modal-details-section {
  scroll-behavior: smooth;
}

.modal-details-section::-webkit-scrollbar {
  width: 8px;
}

.modal-details-section::-webkit-scrollbar-track {
  background: var(--background);
}

.modal-details-section::-webkit-scrollbar-thumb {
  background: var(--border);
  border-radius: 4px;
}

.modal-details-section::-webkit-scrollbar-thumb:hover {
  background: var(--text-secondary);
}
```

## Key Features:

✅ **Click to Open** - Any recipe item opens the full modal  
✅ **Split Layout** - Image on left, recipe details on right  
✅ **Scrollable Content** - Recipe details scroll independently  
✅ **Structured Data** - Ingredients grouped by section  
✅ **Numbered Instructions** - Clear step-by-step guide  
✅ **Responsive** - Stacks vertically on mobile  
✅ **Close Methods** - Click X button or click outside  
✅ **Smooth Animations** - Fade in overlay, slide up modal  
✅ **Beautiful Typography** - Easy to read recipe format  

The modal now beautifully displays your recipes with all the details! 🍽️