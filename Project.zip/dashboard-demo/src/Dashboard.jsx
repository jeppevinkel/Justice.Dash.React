import React from 'react';
import './Dashboard.css';

const Dashboard = () => {
  const [fullscreenImage, setFullscreenImage] = React.useState(null);
  const [selectedRecipe, setSelectedRecipe] = React.useState(null);

  const openFullscreen = (imageSrc) => {
    setFullscreenImage(imageSrc);
  };

  const closeFullscreen = () => {
    setFullscreenImage(null);
  };

  return (
    <div className="dashboard">
      {/* Datadog Background Wallpaper */}
      <div className="datadog-background"></div>
      
      <header className="dashboard-header">
        <div className="header-left">
          <img 
            src="/dd_icon_white.png" 
            alt="Datadog Logo" 
            className="datadog-logo"
          />
          <h1>Dashboard</h1>
        </div>
        <div className="header-actions">
          <time>{new Date().toLocaleDateString('da-DK')}</time>
        </div>
      </header>

      <div className="dashboard-grid">
        {/* Surveillance/On-Duty Widget */}
        <div className="widget widget-surveillance">
          <div className="widget-header">
            <div className="widget-header-left">
              <img src="/dd_icon_white.png" alt="" className="widget-logo" />
              <h2>📋 Overvågning Uge 41</h2>
            </div>
            <span className="status-badge status-active">Aktiv</span>
          </div>
          <div className="widget-content">
            <SurveillanceTeam />
          </div>
        </div>

        {/* Recipe List Widget */}
        <div className="widget widget-recipes">
          <div className="widget-header">
            <div className="widget-header-left">
              <img src="/dd_icon_rgb.png" alt="" className="widget-logo" />
              <h2>Madplan</h2>
            </div>
            <button className="widget-action">⋯</button>
          </div>
          <div className="widget-content">
            <RecipeList onRecipeClick={setSelectedRecipe} />
          </div>
        </div>

        {/* Featured Image Widget */}
        <div className="widget widget-featured">
          <div className="widget-header">
            <div className="widget-header-left">
              <img src="/dd_icon_rgb.png" alt="" className="widget-logo" />
              <h2>Madbillede (Outer Space)</h2>
            </div>
          </div>
          <div className="widget-content widget-image">
            <img src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&h=600&fit=crop" alt="Featured dish" />
          </div>
        </div>

        {/* Weather Widget */}
        <div className="widget widget-weather">
          <div className="widget-header">
            <div className="widget-header-left">
              <img src="/dd_icon_rgb.png" alt="" className="widget-logo" />
              <h2>Vejret - Odense</h2>
            </div>
          </div>
          <div className="widget-content">
            <WeatherChart />
          </div>
        </div>

        {/* Clock Widget */}
        <div className="widget widget-clock">
          <Clock />
          <div className="widget-subtitle">Uge nummer: 41</div>
        </div>

        {/* Stats Widget */}
        {/* <div className="widget widget-stats">
          <div className="widget-header">
            <div className="widget-header-left">
              <img src="/dd_icon_rgb.png" alt="" className="widget-logo" />
              <h2>Rapporteret sikkerhed til Githika</h2>
            </div>
          </div>
          <div className="widget-content">
            <StatsDisplay />
          </div>
        </div> */}

        {/* Photo Gallery Widget */}
        <div className="widget widget-gallery">
          <div className="widget-header">
            <div className="widget-header-left">
              <img src="/dd_icon_rgb.png" alt="" className="widget-logo" />
              <h2>Nyt Domicil</h2>
            </div>
          </div>
          <div className="widget-content">
            <PhotoGallery onImageClick={openFullscreen} />
          </div>
        </div>

        {/* Image Grid Widget */}
        <div className="widget widget-grid-images">
          <div className="widget-content">
            <ImageGrid onImageClick={openFullscreen} />
          </div>
        </div>
      </div>

      {/* Fullscreen Modal */}
      {fullscreenImage && (
        <FullscreenModal imageSrc={fullscreenImage} onClose={closeFullscreen} />
      )}

      {/* Recipe Modal */}
      {selectedRecipe && (
        <RecipeModal recipe={selectedRecipe} onClose={() => setSelectedRecipe(null)} />
      )}
    </div>
  );
};

// SurveillanceTeam Component
const SurveillanceTeam = () => {
  const onDutyPersons = [
    {
      id: 1,
      name: "Lars",
      role: "MDM",
      status: "available",
      avatar: "L",
      color: "#3b82f6" // blue
    },
    {
      id: 2,
      name: "Bjarke",
      role: "Batch/EDI",
      status: "available",
      avatar: "B",
      color: "#8b5cf6" // purple
    }
  ];

  return (
    <div className="surveillance-team">
      {onDutyPersons.map(person => (
        <div key={person.id} className="team-member">
          <div 
            className="member-avatar" 
            style={{ backgroundColor: person.color }}
          >
            {person.avatar}
          </div>
          <div className="member-info">
            <h3>{person.name}</h3>
            <p className="member-role">{person.role}</p>
          </div>
          <div className={`member-status status-${person.status}`}>
            <span className="status-indicator"></span>
            Tilgængelig
          </div>
        </div>
      ))}
    </div>
  );
};

// RecipeList Component
const RecipeList = ({ onRecipeClick }) => {
  const recipes = [
    {
      id: 1,
      title: "Kartoffel-porresuppe - Cremet kartoffelsuppe med ristede kartoffeltern, syltede løg og bacon crumble",
      day: "Tirsdag",
      date: "7/10",
      icon: "🥔",
      image: "https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800",
      ingredients: [
        {
          section: "Kartoffel-porresuppe",
          items: [
            "1 kg kartofler, skrællet og skåret i tern",
            "2 porrer, renset og skåret",
            "1 løg, hakket",
            "2 fed hvidløg, presset",
            "1 liter grøntsagsbouillon",
            "200 ml fløde",
            "Olivenolie, salt og peber"
          ]
        },
        {
          section: "Bacon crumble",
          items: [
            "200 g bacon, skåret i små tern",
            "100 g havregryn",
            "50 g smør"
          ]
        }
      ],
      instructions: [
        {
          title: "Forbered suppen",
          steps: [
            "Varm olivenolie i en stor gryde",
            "Svits løg og porre i 5 minutter",
            "Tilsæt kartofler og bouillon",
            "Kog i 20 minutter til kartoflerne er møre",
            "Blend suppen og tilsæt fløde"
          ]
        },
        {
          title: "Tilbered bacon crumble",
          steps: [
            "Steg bacon sprødt i en pande",
            "Bland med havregryn og smør",
            "Brun i ovnen ved 180°C i 10 minutter"
          ]
        }
      ],
      finalNote: "Servér suppen toppet med bacon crumble og friske urter!"
    },
    {
      id: 2,
      title: "Okonomiyaki - Sprød kålpandekage toppet med teriyakimarinade kylling",
      day: "Onsdag",
      date: "8/10",
      icon: "🥘",
      image: "https://images.unsplash.com/photo-1626804475297-41608ea09aeb?w=800",
      ingredients: [
        {
          section: "Pandekage",
          items: [
            "300 g hvidkål, fintskåret",
            "150 g mel",
            "3 æg",
            "200 ml dashi eller bouillon",
            "2 forårsløg, skåret"
          ]
        },
        {
          section: "Topping",
          items: [
            "400 g kyllingebryst",
            "Teriyakisauce",
            "Forårsløg",
            "Chilimayo",
            "Sesamfrø"
          ]
        }
      ],
      instructions: [
        {
          title: "Lav dej",
          steps: [
            "Bland mel, æg og dashi",
            "Fold kål i dejen",
            "Lad hvile i 15 minutter"
          ]
        },
        {
          title: "Steg pandekagerne",
          steps: [
            "Varm en pande med olie",
            "Hæld dej på panden og form til flade kager",
            "Steg 4-5 minutter på hver side"
          ]
        }
      ],
      finalNote: "Servér med ekstra teriyakisauce og chilimayo!"
    },
    {
      id: 3,
      title: "Brændt blomkål på lun jordskokkepuré, toppet med rejer",
      day: "Torsdag",
      date: "9/10",
      icon: "🥦",
      image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800",
      ingredients: [
        {
          section: "Blomkål",
          items: [
            "1 helt blomkålshoved",
            "Olivenolie",
            "Salt og peber",
            "Friske krydderurter"
          ]
        },
        {
          section: "Jordskokkepuré",
          items: [
            "500 g jordskokker",
            "100 ml fløde",
            "50 g smør",
            "Salt og muskatnød"
          ]
        },
        {
          section: "Topping",
          items: [
            "300 g rejer",
            "Kinaradiser",
            "Æbler i små tern",
            "Friske urter"
          ]
        }
      ],
      instructions: [
        {
          title: "Rist blomkålen",
          steps: [
            "Pensl blomkål med olie",
            "Krydre med salt og peber",
            "Rist i ovn ved 200°C i 40 minutter",
            "Vend halvvejs"
          ]
        },
        {
          title: "Lav puré",
          steps: [
            "Kog jordskokker møre",
            "Mos med fløde og smør",
            "Smag til med salt og muskatnød"
          ]
        }
      ],
      finalNote: "En smuk vegetarisk ret med lækre kontraster!"
    },
    {
      id: 4,
      title: "Boller i karry - klassiske boller i karry med ris",
      day: "Fredag",
      date: "10/10",
      icon: "🍛",
      image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800",
      ingredients: [
        {
          section: "Kødboller",
          items: [
            "500 g hakket oksekød",
            "1 æg",
            "2 spsk mel",
            "Salt og peber",
            "1 løg, finthakket"
          ]
        },
        {
          section: "Karrysauce",
          items: [
            "2 spsk smør",
            "2 spsk mel",
            "2 spsk karrypulver",
            "500 ml bouillon",
            "100 ml fløde"
          ]
        }
      ],
      instructions: [
        {
          title: "Form bollerne",
          steps: [
            "Bland alle ingredienser",
            "Form til små boller",
            "Steg gyldne i smør"
          ]
        },
        {
          title: "Lav sauce",
          steps: [
            "Lav en jævning af smør og mel",
            "Tilsæt karry og bouillon",
            "Kog op og tilsæt fløde",
            "Læg bollerne i saucen"
          ]
        }
      ],
      finalNote: "Klassisk dansk comfort food!"
    },
    {
      id: 5,
      title: "Frikadeller med stuvet hvidkål",
      day: "Mandag",
      date: "13/10",
      icon: "🍖",
      image: "https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=800",
      ingredients: [
        {
          section: "Frikadeller",
          items: [
            "500 g svinekød",
            "1 løg, finthakket",
            "1 æg",
            "3 spsk mel",
            "100 ml mælk",
            "Salt og peber"
          ]
        },
        {
          section: "Stuvet hvidkål",
          items: [
            "1 hvidkålshoved",
            "50 g smør",
            "2 spsk mel",
            "300 ml mælk",
            "Salt, peber og muskatnød"
          ]
        }
      ],
      instructions: [
        {
          title: "Lav frikadellerne",
          steps: [
            "Bland ingredienser til en fast masse",
            "Form flade kager",
            "Steg på medium varme i 4-5 minutter per side"
          ]
        },
        {
          title: "Stuv hvidkålen",
          steps: [
            "Skær kålen i strimler",
            "Kog mørt i letsaltet vand",
            "Lav en hvid sauce og bland kålen i"
          ]
        }
      ],
      finalNote: "Servér med kartofler og god brun sauce!"
    }
  ];

  return (
    <ul className="recipe-list">
      {recipes.map(recipe => (
        <li 
          key={recipe.id} 
          className="recipe-item"
          onClick={() => onRecipeClick(recipe)}
        >
          <span className="recipe-icon">{recipe.icon}</span>
          <div className="recipe-details">
            <h3>{recipe.title}</h3>
            <time>{recipe.day} - {recipe.date}</time>
          </div>
          <svg className="recipe-arrow" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
            <path d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"/>
          </svg>
        </li>
      ))}
    </ul>
  );
};

// WeatherChart Component
const WeatherChart = () => (
  <div className="weather-chart">
    <div className="weather-info">
      <div className="weather-current">
        <span className="weather-icon">☀️</span>
        <span className="weather-temp">18°C</span>
      </div>
      <div className="weather-forecast">
        <div className="forecast-item">
          <span>Mon</span>
          <span>🌤️</span>
          <span>16°</span>
        </div>
        <div className="forecast-item">
          <span>Tue</span>
          <span>☁️</span>
          <span>14°</span>
        </div>
        <div className="forecast-item">
          <span>Wed</span>
          <span>🌧️</span>
          <span>12°</span>
        </div>
        <div className="forecast-item">
          <span>Thu</span>
          <span>⛈️</span>
          <span>11°</span>
        </div>
        <div className="forecast-item">
          <span>Fri</span>
          <span>🌤️</span>
          <span>15°</span>
        </div>
      </div>
    </div>
  </div>
);

// Clock Component
const Clock = () => {
  const [time, setTime] = React.useState(new Date());

  React.useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="clock-display">
      <div className="clock-face">🕐</div>
      <div className="clock-time">
        {time.toLocaleTimeString('da-DK', { hour: '2-digit', minute: '2-digit' })}
      </div>
    </div>
  );
};

// StatsDisplay Component
const StatsDisplay = () => (
  <div className="stats">
    <div className="stat-item">
      <label>Completed Imports:</label>
      <span className="stat-value">64</span>
    </div>
    <div className="progress-bar">
      <div className="progress-fill" style={{width: '89%'}}>89%</div>
    </div>
  </div>
);

// PhotoGallery Component
const PhotoGallery = ({ onImageClick }) => {
  const images = [
    { src: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=600&fit=crop", alt: "Gallery 1" },
    { src: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=800&h=600&fit=crop", alt: "Gallery 2" },
    { src: "https://images.unsplash.com/photo-1572120360610-d971b9d7767c?w=800&h=600&fit=crop", alt: "Gallery 3" }
  ];

  return (
    <div className="photo-grid">
      {images.map((image, index) => (
        <img 
          key={index}
          src={image.src} 
          alt={image.alt} 
          onClick={() => onImageClick(image.src)}
          style={{ cursor: 'pointer' }}
        />
      ))}
    </div>
  );
};

// ImageGrid Component
const ImageGrid = ({ onImageClick }) => {
  const images = [
    { src: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&h=800&fit=crop", alt: "Grid 1" },
    { src: "https://images.unsplash.com/photo-1513584684374-8bab748fbf90?w=800&h=800&fit=crop", alt: "Grid 2" },
    { src: "https://images.unsplash.com/photo-1558036117-15d82a90b9b1?w=800&h=800&fit=crop", alt: "Grid 3" },
    { src: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&h=800&fit=crop", alt: "Grid 4" }
  ];

  return (
    <div className="image-grid">
      {images.map((image, index) => (
        <img 
          key={index}
          src={image.src} 
          alt={image.alt} 
          onClick={() => onImageClick(image.src)}
          style={{ cursor: 'pointer' }}
        />
      ))}
    </div>
  );
};

// FullscreenModal Component
const FullscreenModal = ({ imageSrc, onClose }) => {
  React.useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    
    document.addEventListener('keydown', handleEscape);
    document.body.style.overflow = 'hidden';
    
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [onClose]);

  return (
    <div className="fullscreen-modal" onClick={onClose}>
      <button className="fullscreen-close" onClick={onClose} aria-label="Close">
        ✕
      </button>
      <img 
        src={imageSrc} 
        alt="Fullscreen" 
        onClick={(e) => e.stopPropagation()}
      />
    </div>
  );
};

// RecipeModal Component
const RecipeModal = ({ recipe, onClose }) => {
  React.useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    
    document.addEventListener('keydown', handleEscape);
    document.body.style.overflow = 'hidden';
    
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [onClose]);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </button>

        <div className="modal-grid">
          {/* Recipe Image */}
          <div className="modal-image-section">
            <img src={recipe.image} alt={recipe.title} />
          </div>

          {/* Recipe Details */}
          <div className="modal-details-section">
            <div className="modal-header-content">
              <span className="recipe-icon-large">{recipe.icon}</span>
              <div>
                <h2>{recipe.title}</h2>
                <p className="recipe-meta">
                  <time>{recipe.day} - {recipe.date}</time>
                </p>
              </div>
            </div>

            <div className="recipe-content">
              {/* Ingredients */}
              <section className="recipe-section">
                <h3>Ingredienser:</h3>
                {recipe.ingredients && recipe.ingredients.map((section, idx) => (
                  <div key={idx} className="ingredient-group">
                    <h4>{section.section}</h4>
                    <ul>
                      {section.items.map((item, i) => (
                        <li key={i}>{item}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </section>

              {/* Instructions */}
              <section className="recipe-section">
                <h3>Instruktioner:</h3>
                <ol className="instructions-list">
                  {recipe.instructions && recipe.instructions.map((step, idx) => (
                    <li key={idx}>
                      <strong>{step.title}</strong>
                      <ul>
                        {step.steps.map((substep, i) => (
                          <li key={i}>{substep}</li>
                        ))}
                      </ul>
                    </li>
                  ))}
                </ol>
              </section>

              {/* Final note */}
              {recipe.finalNote && (
                <div className="recipe-note">
                  <strong>{recipe.finalNote}</strong>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
